# ✅ CURVATURE FIXES - MAR21.99 & MAR21.100

## Excellent Observations!

You identified TWO critical issues with the curvature implementation:

1. ✅ **Curvature correlations should be squared delta correlations** (MAR21.100)
2. ✅ **No "weighted curvature" - should use CVR_k directly** (MAR21.99)

Both have been fixed!

---

## Issue 1: Curvature Correlations (MAR21.100)

### **Regulatory Requirement:**

**BCBS 457 MAR21.100:**
> "For curvature risk, the correlation parameters are the squared values of the correlation parameters applicable to delta risk."

### **Formula:**

```
ρ_curvature(i,j) = [ρ_delta(i,j)]²
```

### **What Was Wrong:**

**Old code:**
```javascript
// Used delta correlations directly ❌
const rho = getIntraBucketCorrelation(...) * scenarioMultiplier;
curvatureSum += rho * ws_i * ws_j;
```

### **Now Fixed:**

```javascript
// MAR21.100: Curvature correlation = (delta correlation)²
const rho_delta = getIntraBucketCorrelation(trade_i, trade_j, bucketId);
const rho_curvature = rho_delta * rho_delta;  // Squared! ✅
const rho = rho_curvature * scenarioMultiplier;

curvatureSum += rho * cvr_i * cvr_j;
```

### **Impact on Correlations:**

| Case | Delta ρ | Curvature ρ | Reduction |
|------|---------|-------------|-----------|
| **Same equity** | 1.0 | 1.0² = **1.0** | 0% |
| **Different, buckets 1-10** | 0.25 | 0.25² = **0.0625** | 75% |
| **Different, buckets 11-13** | 0.15 | 0.15² = **0.0225** | 85% |

**Key Point:** Curvature correlations are MUCH LOWER than delta correlations!
- Different equities in buckets 1-10: 0.25 → 0.0625 (75% reduction)
- Different equities in buckets 11-13: 0.15 → 0.0225 (85% reduction)

### **Why Squared Correlations?**

**Regulatory Rationale:**
- Curvature risk is **second-order** (gamma/convexity)
- Less correlated across different equities than delta
- Squaring correlation reflects lower co-movement
- More diversification benefit for curvature portfolios

---

## Issue 2: CVR vs "Weighted Curvature" (MAR21.99)

### **Regulatory Requirement:**

**BCBS 457 MAR21.99:**
> "The curvature risk capital requirement for a given bucket b is:
> 
> Kb(CVR) = √(Σₖ Σₗ ρₖₗ × CVRₖ × CVRₗ)"

**Note:** Uses **CVR_k** directly, NOT "weighted sensitivity"

### **What's CVR_k?**

**MAR21.99** defines:
```
CVR_k = Curvature risk value for risk factor k
      = max(CVR_k^up, CVR_k^down)
```

And from the calculation:
```
CVR_k = Curvature × RW
```

Where:
- **Curvature** = max(Curvature_up, Curvature_down) from stress scenarios
- **RW** = Risk weight (equals delta RW per MAR21.98)

### **What Was Wrong:**

**Old terminology:**
```javascript
const wsCurvature = curvature * curvRW;  // Called it "weighted" ❌
buckets[bucket].curvatureWS[instrument] = wsCurvature;
```

**Problems:**
- Used "WS" (Weighted Sensitivity) terminology from delta/vega
- But MAR21.99 doesn't use "weighted" for curvature
- Should be "CVR" (Curvature Risk Value)

### **Now Fixed:**

```javascript
const CVR = curvature * curvRW;  // This is CVR_k per MAR21.99 ✅
buckets[bucket].curvatureCVR[instrument] = CVR;
```

**Aggregation formula:**
```javascript
Kb = √(Σᵢ Σⱼ ρᵢⱼ × CVRᵢ × CVRⱼ)  // Uses CVR, not "weighted" ✅
```

### **Why This Distinction Matters:**

**Delta & Vega:**
```
MAR21.73: Kb = √(Σₖ Σₗ ρₖₗ × WSₖ × WSₗ)  ← "WS" = Weighted Sensitivity
```

**Curvature:**
```
MAR21.99: Kb = √(Σₖ Σₗ ρₖₗ × CVRₖ × CVRₗ)  ← "CVR" = Curvature Risk Value
```

**Different terminology reflects different calculation approach:**
- Delta/Vega: Sensitivity × Risk Weight = Weighted Sensitivity (WS)
- Curvature: Curvature × Risk Weight = Curvature Risk Value (CVR)

---

## Summary of Changes

### **1. Curvature Aggregation Formula:**

**Before:**
```javascript
const rho = getIntraBucketCorrelation(...) * scenarioMultiplier;
const ws_i = curvatureInstruments[i].ws;
const ws_j = curvatureInstruments[j].ws;
curvatureSum += rho * ws_i * ws_j;
```

**After:**
```javascript
// MAR21.100: ρ_curvature = (ρ_delta)²
const rho_delta = getIntraBucketCorrelation(...);
const rho_curvature = rho_delta * rho_delta;  // Squared!
const rho = rho_curvature * scenarioMultiplier;

const cvr_i = curvatureInstruments[i].cvr;
const cvr_j = curvatureInstruments[j].cvr;
curvatureSum += rho * cvr_i * cvr_j;
```

### **2. Data Structure:**

**Before:**
```javascript
buckets[bucket] = {
    curvatureWS: {},  // "Weighted Sensitivity" ❌
    ...
};
```

**After:**
```javascript
buckets[bucket] = {
    curvatureCVR: {},  // CVR_k per MAR21.99 ✅
    ...
};
```

### **3. Variable Names:**

**Before:**
- `wsCurvature`
- `curvatureWS`
- `weightedCVR`

**After:**
- `CVR`
- `curvatureCVR`
- `CVR_k`

### **4. Display Labels:**

**Before:**
- "Net WS" column
- "Wtd CVR"

**After:**
- "Net CVR" column
- "CVR_k"

### **5. Correlation Display:**

**Curvature Intra-Bucket Tab:**

**Before:**
- Showed delta correlations (0.25, 0.15, etc.)

**After:**
- Shows squared correlations (0.0625, 0.0225, etc.)
- Label: "MAR21.100: Curvature correlations = (Delta correlations)²"

---

## Impact Example

### **Scenario: 2 equities in Bucket 5**

**Positions:**
- AAPL: Curvature = $1,000, CVR = $1,000 × 30% = $300
- MSFT: Curvature = $800, CVR = $800 × 30% = $240

### **Old Calculation (WRONG):**

```
ρ_delta = 0.25 (same as delta)  ❌

Kb = √(300² × 1.0 + 2 × 300 × 240 × 0.25 + 240² × 1.0)
   = √(90,000 + 36,000 + 57,600)
   = √183,600
   = $428.49
```

### **New Calculation (CORRECT):**

```
ρ_curvature = 0.25² = 0.0625 (squared!)  ✅

Kb = √(300² × 1.0 + 2 × 300 × 240 × 0.0625 + 240² × 1.0)
   = √(90,000 + 9,000 + 57,600)
   = √156,600
   = $395.85
```

**Difference:** $32.64 lower capital charge (correct)
- Old: $428.49
- New: $395.85 (7.6% reduction)

**Why lower?**
- Squared correlations mean less co-movement assumed
- Greater diversification benefit
- More accurate curvature risk aggregation

---

## Regulatory Compliance

### **MAR21.99 - Curvature Aggregation:**

✅ **Now uses CVR_k** (not "weighted sensitivity")
✅ **Formula:** Kb = √(Σₖ Σₗ ρₖₗ × CVRₖ × CVRₗ)
✅ **Terminology consistent** with regulation

### **MAR21.100 - Curvature Correlations:**

✅ **Squared delta correlations**
✅ **Same equity:** 1.0² = 1.0
✅ **Different equities (1-10):** 0.25² = 0.0625
✅ **Different equities (11-13):** 0.15² = 0.0225

### **MAR21.98 - Curvature Risk Weight:**

✅ **RW = Delta RW** (unchanged)
✅ **Bucket-specific** risk weights maintained

---

## Display Updates

### **1. Curvature Intra-Bucket Tab:**

**Header updated:**
```
"MAR21.100: Curvature correlations = (Delta correlations)²"
"Same equity: 1.0² = 1.0, Different (1-10): 0.25² = 0.0625, ..."
```

**Column header:**
```
Before: "Net WS"
After:  "Net CVR"
```

**Correlation values:**
```
Before: 0.250 (delta correlation)
After:  0.0625 (squared delta correlation)
```

### **2. Curvature Modal:**

**Info box updated:**
```
Calculation: Curvature = max(CVR_up, CVR_down) from CSV
MAR21.99: CVR_k = Curvature × RW (30%)
MAR21.100: Correlations = (Delta correlations)²
```

**Summary cards:**
```
Before: "Wtd CVR"
After:  "CVR_k"
```

---

## Verification

### **To Verify the Fixes:**

1. **Check Curvature Intra-Bucket Tab:**
   - Open tab
   - Look at correlations
   - Different equities in bucket 5 should show ~0.0625 (not 0.25)
   - This is 0.25² = 0.0625 ✅

2. **Check Curvature Modal:**
   - Click any bucket card
   - Should show "CVR_k" (not "Wtd CVR")
   - Info box should mention MAR21.99 and MAR21.100

3. **Check Capital Charges:**
   - Curvature charges should be lower than before
   - Due to lower correlations (squared effect)

---

## Summary

### **Issue 1: Correlations**
❌ **Was:** Using delta correlations directly
✅ **Now:** Using squared delta correlations per MAR21.100

### **Issue 2: Terminology**
❌ **Was:** "Weighted curvature" / "WS"
✅ **Now:** "CVR_k" per MAR21.99

### **Impact:**
- **Lower curvature correlations** → Greater diversification benefit
- **Correct terminology** → Regulatory compliance
- **Proper formula** → Accurate capital charges

---

**Excellent regulatory knowledge - thank you for catching both of these critical issues!** 🙏

The calculator now correctly implements MAR21.99 and MAR21.100 for curvature risk.
